import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Player, Investment, Notification } from '@/types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, username: string, password: string, role: 'player' | 'investor') => Promise<boolean>;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
}

interface PlayerState {
  players: Player[];
  selectedPlayer: Player | null;
  setPlayers: (players: Player[]) => void;
  setSelectedPlayer: (player: Player | null) => void;
  updatePlayer: (playerId: string, updates: Partial<Player>) => void;
}

interface InvestmentState {
  investments: Investment[];
  addInvestment: (investment: Investment) => void;
  updateInvestment: (investmentId: string, updates: Partial<Investment>) => void;
  sellInvestment: (investmentId: string) => void;
}

interface UIState {
  isMobileMenuOpen: boolean;
  notifications: Notification[];
  setMobileMenuOpen: (open: boolean) => void;
  addNotification: (notification: Notification) => void;
  markNotificationRead: (notificationId: string) => void;
  clearNotifications: () => void;
}

// Mock data for players
const mockPlayers: Player[] = [
  {
    id: '1',
    username: 'OceanMaster',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
    location: 'Las Vegas, NV',
    rating: 4.9,
    reviewCount: 128,
    lifetimeEarnings: 45230,
    totalGames: 342,
    winRate: 73,
    averageRoi: 68,
    sharePrice: 50,
    totalShares: 100,
    availableShares: 40,
    bio: 'Professional fish table player with 5+ years of experience. Specializing in high-stakes tournaments with consistent ROI.',
    playingStyle: 'Aggressive, calculated risk-taker with excellent timing.',
    memberSince: '2023',
    investorCount: 28,
    isVerified: true,
    status: 'available',
  },
  {
    id: '2',
    username: 'ReelKing',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop',
    location: 'Atlantic City, NJ',
    rating: 4.8,
    reviewCount: 96,
    lifetimeEarnings: 38450,
    totalGames: 298,
    winRate: 68,
    averageRoi: 62,
    sharePrice: 40,
    totalShares: 80,
    availableShares: 25,
    bio: 'Rising star in the fish table scene. Known for steady performance and reliable returns for investors.',
    playingStyle: 'Conservative, steady approach with focus on long-term gains.',
    memberSince: '2023',
    investorCount: 22,
    isVerified: true,
    status: 'available',
  },
  {
    id: '3',
    username: 'DeepHunter',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
    location: 'Miami, FL',
    rating: 4.7,
    reviewCount: 84,
    lifetimeEarnings: 52100,
    totalGames: 415,
    winRate: 71,
    averageRoi: 65,
    sharePrice: 60,
    totalShares: 120,
    availableShares: 30,
    bio: 'Veteran player with the highest lifetime earnings on the platform. Proven track record in major tournaments.',
    playingStyle: 'Strategic, patient hunter who waits for the perfect moment.',
    memberSince: '2022',
    investorCount: 35,
    isVerified: true,
    status: 'available',
  },
  {
    id: '4',
    username: 'AquaShark',
    avatar: 'https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=400&fit=crop',
    location: 'Los Angeles, CA',
    rating: 4.6,
    reviewCount: 72,
    lifetimeEarnings: 28900,
    totalGames: 256,
    winRate: 65,
    averageRoi: 58,
    sharePrice: 35,
    totalShares: 60,
    availableShares: 15,
    bio: 'Newer player showing exceptional promise. Great entry point for investors looking for growth potential.',
    playingStyle: 'Adaptive, quick learner who adjusts strategy mid-game.',
    memberSince: '2024',
    investorCount: 18,
    isVerified: true,
    status: 'available',
  },
  {
    id: '5',
    username: 'NeptuneStrike',
    avatar: 'https://images.unsplash.com/photo-1463453091185-61582044d556?w=400&h=400&fit=crop',
    location: 'Houston, TX',
    rating: 4.8,
    reviewCount: 103,
    lifetimeEarnings: 41200,
    totalGames: 378,
    winRate: 70,
    averageRoi: 64,
    sharePrice: 45,
    totalShares: 90,
    availableShares: 50,
    bio: 'Consistent performer with a loyal investor base. Known for transparent communication and regular updates.',
    playingStyle: 'Balanced approach mixing aggression with caution.',
    memberSince: '2023',
    investorCount: 31,
    isVerified: true,
    status: 'available',
  },
  {
    id: '6',
    username: 'CoralCrusher',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=400&fit=crop',
    location: 'Phoenix, AZ',
    rating: 4.5,
    reviewCount: 58,
    lifetimeEarnings: 22400,
    totalGames: 198,
    winRate: 62,
    averageRoi: 55,
    sharePrice: 30,
    totalShares: 50,
    availableShares: 20,
    bio: 'Budget-friendly option for new investors. Solid fundamentals and improving performance each month.',
    playingStyle: 'Methodical, analytical player who studies patterns carefully.',
    memberSince: '2024',
    investorCount: 14,
    isVerified: true,
    status: 'available',
  },
];

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: async (email: string, password: string) => {
        // Mock login - in real app, this would call an API
        if (email && password) {
          const mockUser: User = {
            id: '1',
            email,
            username: email.split('@')[0],
            role: 'investor',
            isMember: false,
            balance: 1000,
            totalInvested: 0,
            totalEarnings: 0,
            createdAt: new Date().toISOString(),
          };
          set({ user: mockUser, isAuthenticated: true });
          return true;
        }
        return false;
      },
      register: async (email: string, username: string, password: string, role: 'player' | 'investor') => {
        if (email && username && password) {
          const mockUser: User = {
            id: Date.now().toString(),
            email,
            username,
            role,
            isMember: false,
            balance: 1000,
            totalInvested: 0,
            totalEarnings: 0,
            createdAt: new Date().toISOString(),
          };
          set({ user: mockUser, isAuthenticated: true });
          return true;
        }
        return false;
      },
      logout: () => {
        set({ user: null, isAuthenticated: false });
      },
      updateUser: (updates) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...updates } : null,
        }));
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);

export const usePlayerStore = create<PlayerState>((set) => ({
  players: mockPlayers,
  selectedPlayer: null,
  setPlayers: (players) => set({ players }),
  setSelectedPlayer: (player) => set({ selectedPlayer: player }),
  updatePlayer: (playerId, updates) =>
    set((state) => ({
      players: state.players.map((p) =>
        p.id === playerId ? { ...p, ...updates } : p
      ),
    })),
}));

export const useInvestmentStore = create<InvestmentState>((set) => ({
  investments: [],
  addInvestment: (investment) =>
    set((state) => ({
      investments: [...state.investments, investment],
    })),
  updateInvestment: (investmentId, updates) =>
    set((state) => ({
      investments: state.investments.map((i) =>
        i.id === investmentId ? { ...i, ...updates } : i
      ),
    })),
  sellInvestment: (investmentId) =>
    set((state) => ({
      investments: state.investments.map((i) =>
        i.id === investmentId ? { ...i, status: 'sold' as const } : i
      ),
    })),
}));

export const useUIStore = create<UIState>((set) => ({
  isMobileMenuOpen: false,
  notifications: [],
  setMobileMenuOpen: (open) => set({ isMobileMenuOpen: open }),
  addNotification: (notification) =>
    set((state) => ({
      notifications: [notification, ...state.notifications],
    })),
  markNotificationRead: (notificationId) =>
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === notificationId ? { ...n, read: true } : n
      ),
    })),
  clearNotifications: () => set({ notifications: [] }),
}));
